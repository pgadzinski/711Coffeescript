require 'test_helper'

class MaxschedulerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
