require 'test_helper'

class OperationhoursHelperTest < ActionView::TestCase
end
