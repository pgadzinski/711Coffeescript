require 'test_helper'

class MaxschedulersHelperTest < ActionView::TestCase
end
