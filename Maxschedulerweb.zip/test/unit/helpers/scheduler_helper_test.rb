require 'test_helper'

class SchedulerHelperTest < ActionView::TestCase
end
