require 'test_helper'

class SitesHelperTest < ActionView::TestCase
end
