require 'test_helper'

class AttributesHelperTest < ActionView::TestCase
end
