require 'test_helper'

class UsersitesHelperTest < ActionView::TestCase
end
