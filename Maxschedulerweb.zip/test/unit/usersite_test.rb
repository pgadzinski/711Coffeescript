require 'test_helper'

class UsersiteTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
