class Attribute < ActiveRecord::Base

	belongs_to :maxscheduler

end
