class Importdatum < ActiveRecord::Base
end
