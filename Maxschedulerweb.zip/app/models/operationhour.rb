class Operationhour < ActiveRecord::Base
end
