module BoardsHelper
end
