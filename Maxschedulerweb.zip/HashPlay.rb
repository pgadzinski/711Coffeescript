
a = {"boat" => 1, "cat" => 2}
b = {"dog" => 3, "cow" => 4}

puts a
puts b

c = a.merge(b)

puts c