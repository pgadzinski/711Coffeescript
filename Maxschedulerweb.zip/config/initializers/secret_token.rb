# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Maxschedulerweb::Application.config.secret_token = 'aac27db4179c2338286d71837c28faf1071d943ea18d728596a4f392b00634876ffc56c72e282aa5a0bd6fddca92cfde4898fc73865d4c9d1bfb2d1e1ece9120'
