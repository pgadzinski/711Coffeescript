module Sessiondata
    
 =begin
    def getmaxschedulerid
        @maxschedulerr = current_user.maxscheduler_id
    end
    
    def getsesssionid
        @site = session[:site]
    end

    def getboardid
        @board = session[:board]
    end
=end  

end
